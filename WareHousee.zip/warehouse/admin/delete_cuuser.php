<?php
 $servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
 $sql = "delete from cu_user";
 if(mysqli_query($conn,$sql))
 {
 	echo '<script>alert("Logout Successfully")</script>';
    echo "<script>window.location.href='http://localhost/php%20minipro/warehouse/index.php'</script>";
 }
 else
 {
 	echo "Error".mysqli_error($conn);
 }
 mysqli_close($conn);
 
?>