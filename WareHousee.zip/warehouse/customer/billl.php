<html>
	<head>
		<meta charset="utf-8">
		<title>Invoice</title>
		<link rel="stylesheet" href="style.css">
		<link rel="license" href="https://www.opensource.org/licenses/mit-license/">
		<script src="script.js"></script>
	</head>
	<body>
		<?php
		$cname= $_GET['cname'];
		$billid=$_GET['id'];
		$billdate=$_GET['bdate'];
		$billrate=$_GET['brate'];
		$adr=$_GET['addre'];
		$prdname=$_GET['prod'];
		$qt=$_GET['qua'];
		$prdrate=$_GET['prodrate'];
		
		?>
		<header>
			<h1>Invoice</h1>
			<address contenteditable>
				<p><?php echo $cname?></p>
				<p><?php echo $adr ?></p>
			</address>
			<span><img alt="" src="http://www.jonathantneal.com/examples/invoice/logo.png"><input type="file" accept="image/*"></span>
		</header>
		<article>
			<h1>Recipient</h1>
			<address contenteditable>
				<p>WAREHOUSE SYSTEM</p>
			</address>
			<table class="meta">
				<tr>
					<th><span contenteditable>Invoice No</span></th>
					<td><span contenteditable><?php echo $billid?></span></td>
				</tr>
				<tr>
					<th><span contenteditable>Date</span></th>
					<td><span contenteditable><?php echo $billdate?></span></td>
				</tr>
				<tr>
					<th><span contenteditable>Amount Due</span></th>
					<td><span contenteditable>$<?php echo $billrate?></span></td>
				</tr>
			</table>
			<table class="inventory">
				<?php 


				?>
				<thead>
					<tr>
						<th><span contenteditable>Item</span></th>
						<th><span contenteditable>Rate</span></th>
						<th><span contenteditable>Quantity</span></th>
						<th><span contenteditable>Price</span></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><span contenteditable><?php echo $prdname?></span></td>
						<td><span data-prefix>$</span><span contenteditable><?php echo $prdrate?></span></td>
						<td><span contenteditable><?php echo $qt?></span></td>
						<td><span data-prefix>$<?php echo $billrate?></span></td>
					</tr>
				</tbody>
			</table>
			<table class="balance">
				<tr>
					<th><span contenteditable>Total</span></th>
					<td><span data-prefix>$</span><span><?php echo $billrate?></span></td>
				</tr>
				<!--<tr>
					<th><span contenteditable>Amount Paid</span></th>
					<td><span data-prefix>$</span><span contenteditable>0.00</span></td>
				</tr>
				<tr>
					<th><span contenteditable>Balance Due</span></th>
					<td><span data-prefix>$</span><span>600.00</span></td>
				</tr>-->
			</table>
		</article>
		<aside>
			<h1><span contenteditable>Additional Notes</span></h1>
			<div contenteditable>
				<p>A finance charge of 1.5% will be made on unpaid balances after 30 days.</p>
			</div>
		</aside>
	</body>
</html>