<?php
$servername="localhost";
$username="root";
$password="";
$dbname="WMS";
$usertype=$_REQUEST['user_name'];
$conn= mysqli_connect($servername, $username, $password, $dbname);

$mobileno = $_REQUEST ["mobile"];  
if (!preg_match ("/^[0-9]*$/", $mobileno) ){  
    $ErrMsg = "Only numeric value is allowed.";  
    echo $ErrMsg;  
} else {  
    echo $mobileno;  
}  


if(!$conn)
{
    die("Connection failed".mysqli_connect_error());
}
if($usertype=="Stockist")
{
   //$sql="insert into stockist (st_name,st_address,st_mobile,st_email,st_pswd) values('$_REQUEST[name]','$_REQUEST[address]','$_REQUEST[mobile]','$_REQUEST[email]','$_REQUEST[password]')";//
	$sql="insert into temp_reg (name,address,mobile,email,pswd,type) values('$_REQUEST[name]','$_REQUEST[address]','$_REQUEST[mobile]','$_REQUEST[email]','$_REQUEST[password]','$_REQUEST[user_name]')";

}
elseif ($usertype=="Supplier")
{
	//$sql="insert into supplier (s_name,s_address,s_mobile,s_email,s_pswd) values('$_REQUEST[name]','$_REQUEST[address]','$_REQUEST[mobile]','$_REQUEST[email]','$_REQUEST[password]')";//

	$sql="insert into temp_reg (name,address,mobile,email,pswd,type) values('$_REQUEST[name]','$_REQUEST[address]','$_REQUEST[mobile]','$_REQUEST[email]','$_REQUEST[password]','$_REQUEST[user_name]')";
	
	//echo '<script type="text/javascript"> alert("Please wait for Stockist approval");window.location="http://localhost/php%20minipro/warehouse/index.php";</script>';//
}
else 
{
	//$sql="insert into customer (c_name,c_address,c_mobile,c_email,c_pswd) values('$_REQUEST[name]','$_REQUEST[address]','$_REQUEST[mobile]','$_REQUEST[email]','$_REQUEST[password]')";//

	$sql="insert into temp_reg (name,address,mobile,email,pswd,type) values('$_REQUEST[name]','$_REQUEST[address]','$_REQUEST[mobile]','$_REQUEST[email]','$_REQUEST[password]','$_REQUEST[user_name]')";
}

if(mysqli_query($conn, $sql))
{
    echo '<script>alert("Inserted Successfully")</script>';
    echo "<script>window.location.href='http://localhost/php%20minipro/warehouse/index.php'</script>";
}
else
{
    echo"Error".mysqli_error($conn);
}
mysqli_close($conn);
?>