<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
//Check connection
if(!$conn)
{
    die("Connection Failed : ".mysqli_connect_error());
}
//Create table
$sql="CREATE TABLE customer
        (
        c_id INT(10)  PRIMARY KEY AUTO_INCREMENT,
        c_name VARCHAR(20) NOT NULL,
        C_address VARCHAR(50) NOT NULL,
        c_mobile INT(12) NOT NULL,
        c_email VARCHAR(20) NOT NULL,
        c_pswd VARCHAR(15) NOT NULL
        )";

if(mysqli_query($conn, $sql))
 {
    echo "Table customer created successfully";
 }
else
 {
    echo "Error creating table:".mysqli_error($conn);
 }
 mysqli_close($conn);
?>

