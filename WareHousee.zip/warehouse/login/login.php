<?php
session_start();
//$username=$_REQUEST['uname'];
//$password=$_REQUEST['pswd'];
//$usertype=$_REQUEST['user_role'];
$_SESSION['uname']="";
$_SESSION['user_role']="";

$servername="localhost";
$username="root";
$password="";
$dbname="WMS";

$conn= mysqli_connect($servername, $username, $password, $dbname);

if(!$conn)
{
    die("Connection failed".mysqli_connect_error());
}

if($_POST)
{
	$uname=$_POST['uname'];
	$pswd=$_POST['pswd'];
	$type=$_POST['user_role'];
	if($type=="stockist")
    {
	  $checker= mysqli_query($conn,"select * from stockist where st_email='$uname' and st_pswd='$pswd' ");
	  if($checker->num_rows==1)
	  {
	  	$rows=  mysqli_fetch_assoc($checker);
              
                 $cid =$rows['c_id']; 
               	mysqli_query($conn,$sq="insert into cu_user values ('$uname','$cid')");

	  	$_SESSION['uname']=$uname;
	  	$_SESSION['user_role']='stockist';
	    header('location: /php%20minipro/warehouse/stockist/index.php');

	  }

	}
	  else if($type=="supplier")
    {
	  $checker= mysqli_query($conn,"select * from supplier where s_email='$uname' and s_pswd='$pswd' ");
	  if($checker->num_rows==1)
	  {
	  	$rows=  mysqli_fetch_assoc($checker);
              
                 $cid =$rows['c_id']; 
               	mysqli_query($conn,$sq="insert into cu_user values ('$uname','$cid')");
	  	$_SESSION['uname']=$uname;
	  	$_SESSION['user_role']='supplier';
	    header('location: /php%20minipro/warehouse/supplier/index.php');

	  }
	  
    }
    else if($type=="customer")
    {
	  $checker= mysqli_query($conn,"select * from customer where c_email='$uname' and c_pswd='$pswd' ");
	  if($checker->num_rows==1)
	  {
         
        //$sq="insert into cu_user (UNAME,c_id)values ('$_REQUEST[$uname]')";

        
      
              $rows=  mysqli_fetch_assoc($checker);
              
                 $cid =$rows['c_id']; 
               	mysqli_query($conn,$sq="insert into cu_user values ('$uname','$cid')");
              
           
	  	$_SESSION['uname']=$uname;
	  	$_SESSION['user_role']='customer';
	    header('location: /php%20minipro/warehouse/customer/index.php');

	  }
	  
    }
    else
    {
    	$checker= mysqli_query($conn,"select * from admin where name='$uname' and apswd='$pswd' ");
	  if($checker->num_rows==1)
	  {
	  	$rows=  mysqli_fetch_assoc($checker);
              
                 $cid =$rows['c_id']; 
               	mysqli_query($conn,$sq="insert into cu_user values ('$uname','$cid')");
	  	$_SESSION['uname']=$uname;
	  	$_SESSION['user_role']='customer';
	    header('location: /php%20minipro/warehouse/admin/indexa.php');
	}

    }

}

?>


