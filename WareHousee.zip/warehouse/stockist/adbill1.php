<?php
 $servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
    die("Connection Failed : ".mysqli_connect_error());
}

	if($_POST)
	{

	$cname= $_POST['cname'];
	$pname= $_POST['pname'];
	$amt= $_POST['amount'];
	$qty= $_POST['quantity'];
	$bid= $_POST['bid'];

    $checker1=mysqli_query($conn,"select * from booking join customer on booking.c_id=customer.c_id and booking.c_id in (select c_id from cu_user) join stock on booking.p_id=stock.p_id order by booking.b_id desc limit 1");
	$rows=  mysqli_fetch_assoc($checker1);
                 $cid =$rows['c_id'];
                 $pid =$rows['p_id'];
    $sq= "update stock set quantity = quantity-$qty where p_id=$pid"; 
     mysqli_query($conn,$sq);
    $sql = "insert into bills (c_id,b_id,t_rate) values($cid,$bid,$amt)";
   
}
    if(mysqli_query($conn,$sql))
 {
 	echo '<script>alert("Bill Added Successfully")</script>';
    echo "<script>window.location.href='http://localhost/php%20minipro/warehouse/stockist/index.php'</script>";
 }

 
 else
 {
 	echo "Error".mysqli_error($conn);
 }	
 
 mysqli_close($conn);
 
?>