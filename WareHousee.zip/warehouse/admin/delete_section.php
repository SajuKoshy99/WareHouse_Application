<?php
 $servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
 $sql = "delete from temp_reg where id= '" .$_GET["id"]. " '";
 if(mysqli_query($conn,$sql))
 {
 	echo '<script>alert("Deleted Successfully")</script>';
    echo "<script>window.location.href='http://localhost/php%20minipro/warehouse/admin/indexa.php'</script>";
 }
 else
 {
 	echo "Error".mysqli_error($conn);
 }
 mysqli_close($conn);
 
?>