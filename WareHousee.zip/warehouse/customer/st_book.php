<?php
 $servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
if($_POST)
{

	$pid= $_REQUEST['id'];
	$qty= $_REQUEST['qty'];
	$rate= $_REQUEST['rate'];
	$checker=mysqli_query($conn,"select * from cu_user ");
	$rows=  mysqli_fetch_assoc($checker);
              
                 $cid =$rows['c_id'];
    $sql = "insert into booking (p_id,qty,b_rate,c_id) values($pid,$qty,$rate,$cid)";

}
 
 
 if(mysqli_query($conn,$sql))
 {
 	echo '<script>alert("Booking Successfully")</script>';
    echo "<script>window.location.href='http://localhost/php%20minipro/warehouse/customer/index.php'</script>";
 }

 
 else
 {
 	echo "Error".mysqli_error($conn);
 }
 mysqli_close($conn);
 
?>