<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
//Check connection
if(!$conn)
{
    die("Connection Failed : ".mysqli_connect_error());
}
//Create table
$sql="CREATE TABLE stock
        (
        p_id INT(10)  PRIMARY KEY,
        p_name VARCHAR(20) NOT NULL,
        rate INT(10) NOT NULL,
        quantity int(10) not null,
        pic LONGBLOB NOT NULL
        )";

if(mysqli_query($conn, $sql))
 {
    echo "Table stock created successfully";
 }
else
 {
    echo "Error creating table:".mysqli_error($conn);
 }
 mysqli_close($conn);
?>

