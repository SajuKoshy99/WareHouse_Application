<?php

$servername="localhost";
$username="root";
$password="";
$dbname="WMS";

$conn= mysqli_connect($servername, $username, $password, $dbname);

if(!$conn)
{
    die("Connection failed".mysqli_connect_error());
}

$sql="insert into stock (p_id,p_name,rate,quantity,pic) values('$_REQUEST[id]','$_REQUEST[name]','$_REQUEST[rate]','$_REQUEST[qty]','$_REQUEST[image]')";
  
if(mysqli_query($conn, $sql))
{
    echo '<script>alert(Stock Inserted Successfully")</script>';
    echo "<script>window.location.href='http://localhost/php%20minipro/warehouse/stockist/index.php'</script>";
}
else
{
    echo"Error".mysqli_error($conn);
}
mysqli_close($conn);
?>