<?php
 $servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
 $sql1 = "update booking set status = 1 where b_id= '".$_GET["id"]."'";
 if(mysqli_query($conn,$sql1))
 {
 	echo '<script>alert("Product Delivered Successfully")</script>';
    echo "<script>window.location.href='http://localhost/php%20minipro/warehouse/supplier/index.php'</script>";
 }
 else
 {
 	echo "Error".mysqli_error($conn);
 }
 mysqli_close($conn);
 
?>