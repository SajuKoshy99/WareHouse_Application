<html>
    <head>
        <title>
        </title>
    </head>
    <body>
        <form action="admin_login.php" method="POST">
            Id: <input type="text" name="id"><br>
            Name:<input type="text" name="name"><br>
            Password: <input type="text" name="apswd"><br>
            <button name="submit"> INSERT</button>
        </form>
    </body>
</html>