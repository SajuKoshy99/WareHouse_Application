<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
//Check connection
if(!$conn)
{
    die("Connection Failed : ".mysqli_connect_error());
}
//Create table
$sql="CREATE TABLE bills
        (
        bill_id INT(10)  PRIMARY KEY auto_increment,
        c_id INT(10), 
        b_id INT(10),
        qty BIGINT(100),
        bill_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        foreign key(c_id) references customer(c_id),foreign key(b_id) references booking(b_id)
        )";

if(mysqli_query($conn, $sql))
 {
    echo "Table bill created successfully";
 }
else
 {
    echo "Error creating table:".mysqli_error($conn);
 }
 mysqli_close($conn);
?>

