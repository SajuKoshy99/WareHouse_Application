<!DOCTYPE html>
<html lang="en">
  <head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <style>
      /* Remove the navbar's default margin-bottom and rounded borders */ 
      .navbar {
      margin-bottom: 4px;
      border-radius: 0;
      }
      /* Add a gray background color and some padding to the footer */
      footer {
      background-color: #f2f2f2;
      padding: 25px;
      }
      .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
      min-height:200px;
      }
      .navbar-brand
      {
      padding:5px 40px;
      }
      .navbar-brand:hover
      {
      background-color:#ffffff;
      }
      /* Hide the carousel text when the screen is less than 600 pixels wide */
      @media (max-width: 600px) {
      .carousel-caption {
      display: none; 
      }
      }
    </style>
  </head>
  <body>
    <style>
      .box
      {
      width: 100%;
      max-width: 1390px;
      border-radius: 5px;
      border:1px solid #ccc;
      padding: 15px;
      margin: 0 auto;                
      margin-top:50px;
      box-sizing:border-box;
      }
    </style>
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/bootstrap-datepicker1.js"></script>
    <script>
      $(document).ready(function(){
        $('#order_date').datepicker({
          format: "yyyy-mm-dd",
          autoclose: true
        });
      });
    </script>
        
      <h3 align="center">Invoice </h3>

      <br />
      <div align="right">
        <a href="http://localhost/php%20minipro/warehouse/customer/index.php" class="btn btn-info btn-xs">BACK</a>
      </div>
      <br />
      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Bill ID</th>
            <th>Bill Date</th>
            <th>Customer Name</th>
            <th>Total Amount</th>
            <th>INVOICE</th>
            
          </tr>
        </thead>
        <?php
        $servername = "localhost";
        $username="root";
        $password="";
        $dbname="WMS";
        $conn = mysqli_connect($servername,$username,$password,$dbname);
        if(!$conn)
        {
            die("Connection Failed : ".mysqli_connect_error());
        }
          /*$checker=mysqli_query($conn,"select * from cu_user ");
             $rows=  mysqli_fetch_assoc($checker);
              
                 $cid =$rows['c_id'];*/
            $sql="select * from bills join customer on bills.c_id=customer.c_id and bills.c_id in (select c_id from cu_user) order by bills.c_id desc limit 1";  
            $sql1="select * from stock join booking on stock.p_id=booking.p_id order by booking.b_date desc limit 1"; 
            $result= mysqli_query($conn, $sql);
            $result1= mysqli_query($conn, $sql1);
            if(mysqli_num_rows($result)>0 )
           {
              if(mysqli_num_rows($result1)>0)
              {
              while($rows=  mysqli_fetch_assoc($result))
              {
        while($rowss=  mysqli_fetch_assoc($result1))
                 {
                 $bid =$rows['bill_id']; 
                 $c_name= $rows['c_name'];
                 $bill_date=$rows['bill_date'];
                 $rate=$rows['t_rate'];
                 $product=$rowss['p_name'];
                 $qty=$rowss['qty'];
                 $address=$rows['C_address'];
                 $prate=$rowss['b_rate'];
                
                    echo '
                      <tr>
                <td>'.htmlspecialchars($bid).'</td>
                <td>'.htmlspecialchars($bill_date).'</td>
                <td>'.htmlspecialchars($c_name).'</td>
                <td>'.htmlspecialchars($rate).'</td>


                <td><a href="billl.php?pdf=1&id='.htmlspecialchars($bid).'
                &cname='.htmlspecialchars($c_name).'&bdate='.htmlspecialchars($bill_date).'
                &brate='.htmlspecialchars($rate).'&prod='.htmlspecialchars($product).'
                &qua='.htmlspecialchars($qty).'&addre='.htmlspecialchars($address).'
                &prodrate='.htmlspecialchars($prate).'
                ">INVOICE</a></td>
                
              </tr>
            ';
            }
          }
        }
      }
        ?>
      </table>
     
    </div>
    <br>
    <footer class="container-fluid text-center">
      <p></p>
    </footer>
  </body>
</html>