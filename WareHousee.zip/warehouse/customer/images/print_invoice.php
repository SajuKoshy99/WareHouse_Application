<?php
//print_invoice.php
if(isset($_GET["pdf"]) && isset($_GET["id"]))
{
 require_once 'pdf.php';
 $servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
    die("Connection Failed : ".mysqli_connect_error());
}

$id=$_GET["id"];
 $sql= mysqli_query($conn,"select * from booking where b_id = $id");
$row=  mysqli_fetch_assoc($sql);
$bid =$row['b_id'];
$pid =$row['p_id'];

 $sql1= "select * from bills join customer on bills.c_id=customer.c_id where bills.b_id=$id";
  $result= mysqli_query($conn, $sql1);
 if(mysqli_num_rows($result)>0)
 {
  
  $output .= '
   <table width="100%" border="1" cellpadding="5" cellspacing="0">
    <tr>
     <td colspan="2" align="center" style="font-size:18px"><b>Invoice</b></td>
    </tr>
    <tr>
     <td colspan="2">
      <table width="100%" cellpadding="5">
       <tr>
        <td width="65%">
         To,<br />
         <b>RECEIVER (BILL TO)</b><br />
         Name : '.$row["c_name"].'<br /> 
         Billing Address : '.$row["c_address"].'<br />
        </td>
        <td width="35%">
         Reverse Charge<br />
         Invoice No. : '.$result["b_id"].'<br />
         Invoice Date : '.$result["bill_date"].'<br />
        </td>
       </tr>
      </table>
      <br />
      <table width="100%" border="1" cellpadding="5" cellspacing="0">
       <tr>
        <th>Sr No.</th>
        <th>Item Name</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Actual Amt.</th>
        <th>Total</th>
       </tr>
       <tr>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
       </tr>';


 $sql2= "select * from stock where p_id=$pid";
  $result1= mysqli_query($conn, $sql2);
 if(mysqli_num_rows($result1)>0)
 {
   $output .= '
   <tr>
    <td>'.$count.'</td>
    <td>'.$result1["p_name"].'</td>
    <td>'.$row["qty"].'</td>
    <td>'.$result1["rate"].'</td>
    <td>'.$result["t_rate"].'</td>
    <td>'.$result["t_rate"].'</td>
   </tr>
   ';
}
  $output .= '
  
  <tr>
   <td colspan="11"><b>Total Amt :</b></td>
   <td align="right">'.$row["t_rate"].'</td>
  </tr>
  
  ';
  $output .= '
      </table>
     </td>
    </tr>
   </table>
  ';
 }
 $pdf = new Pdf();
 $file_name = 'Invoice-'.$row["b_id"].'.pdf';
 $pdf->loadHtml($output);
 $pdf->render();
 $pdf->stream($file_name, array("Attachment" => false));
}
?>