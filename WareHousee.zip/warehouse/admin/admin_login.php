<?php

$servername="localhost";
$username="root";
$password="";
$dbname="WMS";

$conn= mysqli_connect($servername, $username, $password, $dbname);

if(!$conn)
{
    die("Connection failed".mysqli_connect_error());
}

$sql="insert into admin (aid,name,apswd) values('$_REQUEST[id]','$_REQUEST[name]','$_REQUEST[apswd]')";

if(mysqli_query($conn, $sql))
{
    echo '<script>alert(Inserted Successfully")</script>';
    //echo "<script>window.location.href='http://localhost/php%20minipro/warehouse/stockist/index.php'</script>";
}
else
{
    echo"Error".mysqli_error($conn);
}
mysqli_close($conn);
?>