<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
//Check connection
if(!$conn)
{
    die("Connection Failed : ".mysqli_connect_error());
}
//Create table
$sql="CREATE TABLE booking
        (
        b_id INT(10)  PRIMARY KEY AUTO_INCREMENT,
        p_id INT(20),
        b_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        qty BIGINT(100),
        b_rate INT(10),
        c_id INT(10), foreign key(c_id) references customer(c_id),foreign key(p_id) references stock(p_id)
        )";

if(mysqli_query($conn, $sql))
 {
    echo "Table booking created successfully";
 }
else
 {
    echo "Error creating table:".mysqli_error($conn);
 }
 mysqli_close($conn);
?>

