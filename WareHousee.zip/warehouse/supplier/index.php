
<!DOCTYPE html>
<html lang="en">
<head>
<title>SUPPLIER</title>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Knack Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	Smart Phone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all"> 
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script> 
<!-- //js -->	
<!-- web-fonts -->
<link href='//fonts.googleapis.com/css?family=Niconne' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!-- //web-fonts -->  
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons --> 
<!-- start-smooth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>	
<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
		
		$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
</script>
<!-- //end-smooth-scrolling -->	
</head> 
<body> 
	<!-- top-nav -->
	<div class="top-nav">
		<nav class="navbar navbar-default">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						Menu
					</button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-scenter cl-effect-15">
						<li><a href="index.php" class="active">Home</a></li>					
						<li><a href="cview.php" >Customer</a></li>
						<li><a href="stock_view.php">Stock</a></li>
						<li><a class="nav-link" href= "delete_cuuser.php" >Logout</a></li>
					</ul>	
					<div class="clearfix"> </div>
				</div>
			</div>	
		</nav>		
	</div>	
	<!-- banner -->
	<div class="banner">
		<div class="banner-info">
			<div class="container">	 
				<div class="banner-text">
					<h1><a href="index.php"> SUPPLIER SYSTEM</a></h1>
				
					</div>
				</div>
			</div>			
		</div>			
	</div>			
	<!-- //banner -->
	<!-- welcome -->
	
	

	<div class="footer">
		<div class="container">
			<div class="footer-left">
				<p>SUPPLIER MNGMT. All rights reserved | Design by <a href="index.php">WMS</a></p>
			</div>
			<div class="footer-right"> 
				<h2><a href="index.php">SUPPLIER SYSTEM</a></h2> 
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!-- //footer -->
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>
</html> 