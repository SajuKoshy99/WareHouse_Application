<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="WMS";
//Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
//Check connection
if(!$conn)
{
    die("Connection Failed : ".mysqli_connect_error());
}
//Create table
$sql="CREATE TABLE stockist
        (
        st_id INT(10)  PRIMARY KEY AUTO_INCREMENT,
        st_name VARCHAR(20) NOT NULL,
        st_address VARCHAR(50) NOT NULL,
        st_mobile INT(12) NOT NULL,
        st_email VARCHAR(20) NOT NULL,
        st_pswd VARCHAR(15) NOT NULL
        )";

if(mysqli_query($conn, $sql))
 {
    echo "Table stockist created successfully";
 }
else
 {
    echo "Error creating table:".mysqli_error($conn);
 }
 mysqli_close($conn);
?>

