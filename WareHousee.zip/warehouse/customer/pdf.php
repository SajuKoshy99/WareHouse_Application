<?php
//pdf.php;
require_once 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;

class Pdf extends Dompdf{
 public function __construct() {
        parent::__construct();
    }

}


    /*$dompdf= new Dompdf();
    $dompdf->loadHTML($output);
    $dompdf->setPaper('A4','landscape');
    $dompdf->render();
    $dompdf->stream($filename,array("Attachment" => 0 ));*/
?>